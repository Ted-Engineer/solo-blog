title: Java插件化在同程艺龙的实践（一）
date: '2019-08-26 18:34:23'
updated: '2019-08-26 22:03:33'
tags: [Java, 插件化, module, plugin]
permalink: /articles/2019/08/26/1566815663620.html
---
说到Java插件化，在Java9之前，必须要提到的就是自定义ClassLoader。
关于Java的ClassLoader的基本定义就不多记录了。

由于交易系统需求频繁，导致各种校验器、管理器、处理器总在新增，
改的痛苦痛苦痛苦的一笔，这样的日子再也不想过了，怎么办呢，
如果我们把某一具体业务相关的valiator，manager，handler 的实现放在一个jar包里，然后可以随时的加载卸载，这样就再也不用每周熬夜就为了发布一下系统了。
做到Jar包的动态加载卸载，需要注意class的隔离，防止class冲突，那么
其中关键之一就是使用ClassLoader去加载jar包。
自定义一个ClassLoader怎么做?

	最简单的办法就是继承URLClassLoader,并重写loadClass方法。
其中关于Java ClassLoader的概念中，最熟悉的应该是双亲委派机制，
那么我们自己定义ClassLoader去加载Jar包的时候，就要注意以下这个双亲委派机制了，由于主程和Jar包，都是用Java实现的，那么JDK自带的Class，在两边都会存在，然后加载jar包的时候，JDK自带的Class是不能被加载两次的，因为会反序列化失败。

示例代码如下：
```
public Class<?> loadClass(String className) throws ClassNotFoundException {
        synchronized (getClassLoadingLock(className)) {
            if (className.startsWith(JAVA_PACKAGE_PREFIX)) {
                return findSystemClass(className);
            }

            if (className.startsWith(PLUGIN_PACKAGE_PREFIX)) {
                return getParent().loadClass(className);
            }

            log.trace("Received request to load class '{}'", className);

            Class<?> loadedClass = findLoadedClass(className);
            if (loadedClass != null) {
                log.trace("Found loaded class '{}'", className);
                return loadedClass;
            }

            if (!parentFirst) {

                loadedClass = loadSelfAndParentClass(className);
                if (loadedClass != null) {
                    log.trace("Found class '{}' in dependencies", className);
                    return loadedClass;
                }
                log.trace("Couldn't find class '{}' in module classpath. Delegating to parent", className);

                return super.loadClass(className);
            } else {

                try {
                    return super.loadClass(className);
                } catch (ClassCastException e) {
                }

                log.trace("Couldn't find class '{}' in parent. Delegating to module classpath", className);

                loadedClass = loadSelfAndParentClass(className);
                if (loadedClass != null) {
                    log.trace("Found class '{}' in dependencies", className);
                    return loadedClass;
                }

                throw new ClassNotFoundException(className);
            }
        }
    }
```

今天先写到这里
//TODO。
